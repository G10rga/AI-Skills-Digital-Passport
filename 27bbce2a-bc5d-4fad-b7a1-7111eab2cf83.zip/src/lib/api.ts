/**
 * Mock API. Every exported function maps 1:1 to a backend endpoint
 * documented in API_CONTRACT.md. To connect the real backend, replace the
 * body of each function with a fetch() to `${API_BASE}/...` — the
 * components never touch the mock store directly.
 */
import seed from "@/data/records.json";
import type {
  Issuer,
  Passport,
  PassportSkill,
  PassportSummary,
  PassportVersion,
  SkillRecord,
  SyncResult,
  VerifyResult,
} from "./types";

export const API_BASE = import.meta.env["VITE_API_BASE_URL"] ?? "/api";

export const BTU_ISSUER: Issuer = {
  name: "Business and Technology University (BTU)",
  did: "did:web:btu.edu.ge",
  walletAddress: "0xB7U0000000000000000000000000000000A15C",
};
const NETWORK = "Polygon Amoy (testnet)";
const STORE_KEY = "btu-passport-mock-v1";

const wait = (ms = 250) => new Promise((r) => setTimeout(r, ms));

// ---------- hashing ----------
export async function sha256(input: string | ArrayBuffer): Promise<string> {
  const data = typeof input === "string" ? new TextEncoder().encode(input) : input;
  const buf = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

/** Canonical content that gets hashed and anchored on-chain. */
export function canonicalPassport(
  p: Pick<Passport, "passportId" | "firstName" | "lastName" | "firstIssued">,
  version: number,
  skills: PassportSkill[],
) {
  return JSON.stringify({
    passportId: p.passportId,
    firstName: p.firstName,
    lastName: p.lastName,
    firstIssued: p.firstIssued,
    version,
    issuer: BTU_ISSUER.did,
    skills: [...skills]
      .sort((a, b) => a.recordId.localeCompare(b.recordId))
      .map((s) => [s.skillId, s.skillName, s.skillCategory, s.badgeCode, s.dateEarned, s.skillDescription]),
  });
}

// ---------- mock store ----------
interface Store {
  records: SkillRecord[];
  passports: Record<string, Passport>;
}
let store: Store | null = null;

const toSkill = (r: SkillRecord): PassportSkill => ({
  recordId: r.recordId,
  skillId: r.skillId,
  skillName: r.skillName,
  skillCategory: r.skillCategory,
  badgeCode: r.badgeCode,
  skillDescription: r.skillDescription,
  dateEarned: r.dateEarned,
});

async function makeVersion(p: Passport, version: number, skills: PassportSkill[], issuedAt: string): Promise<PassportVersion> {
  const documentHash = await sha256(canonicalPassport(p, version, skills));
  const txHash = "0x" + (await sha256("tx:" + documentHash));
  return {
    version,
    issuedAt,
    skills,
    documentHash,
    verificationCode: `${p.passportId.replace("BTU-AI-", "")}-V${version}-${documentHash.slice(0, 8).toUpperCase()}`,
    txHash,
    network: NETWORK,
    blockNumber: 18_400_000 + parseInt(documentHash.slice(0, 5), 16),
  };
}

async function getStore(): Promise<Store> {
  if (store) return store;
  if (typeof window !== "undefined") {
    const saved = window.localStorage.getItem(STORE_KEY);
    if (saved) return (store = JSON.parse(saved));
  }
  const records = (seed as SkillRecord[]).map((r) => ({ ...r }));
  const passports: Record<string, Passport> = {};
  for (const r of records) {
    passports[r.passportId] ??= {
      passportId: r.passportId,
      studentId: r.studentId,
      firstName: r.firstName,
      lastName: r.lastName,
      email: r.email,
      program: r.program,
      educationLevel: r.educationLevel,
      studentStatus: r.studentStatus,
      firstIssued: r.firstIssued,
      versions: [],
    };
  }
  for (const p of Object.values(passports)) {
    const synced = records.filter((r) => r.passportId === p.passportId && r.syncStatus === "SYNCED");
    if (synced.length) {
      p.versions.push(await makeVersion(p, 1, synced.map(toSkill), synced[0]?.syncedAt?.replace(" UTC", "Z").replace(" ", "T") ?? new Date().toISOString()));
    }
  }
  store = { records, passports };
  persist();
  return store;
}

function persist() {
  if (store && typeof window !== "undefined") window.localStorage.setItem(STORE_KEY, JSON.stringify(store));
}

export async function resetDemoData() {
  store = null;
  if (typeof window !== "undefined") window.localStorage.removeItem(STORE_KEY);
  await getStore();
}

// ---------- endpoints ----------

/** GET /passports */
export async function listPassports(): Promise<PassportSummary[]> {
  await wait();
  const s = await getStore();
  return Object.values(s.passports).map((p) => {
    const latest = p.versions.at(-1);
    return {
      passportId: p.passportId,
      studentId: p.studentId,
      fullName: `${p.firstName} ${p.lastName}`,
      program: p.program,
      latestVersion: latest?.version ?? null,
      skillCount: latest?.skills.length ?? 0,
      pendingCount: s.records.filter((r) => r.passportId === p.passportId && r.syncStatus !== "SYNCED" && r.syncStatus !== "DUPLICATE").length,
    };
  });
}

/** GET /passports/:passportId */
export async function getPassport(passportId: string): Promise<Passport | null> {
  await wait();
  const s = await getStore();
  return s.passports[passportId] ?? null;
}

/** GET /me/passport  (student, authenticated) */
export async function getMyPassport(email: string): Promise<Passport | null> {
  await wait();
  const s = await getStore();
  return Object.values(s.passports).find((p) => p.email.toLowerCase() === email.toLowerCase()) ?? null;
}

/** GET /records  (admin) — mirror of the Google Sheet */
export async function listRecords(): Promise<SkillRecord[]> {
  await wait();
  return (await getStore()).records;
}

/** POST /sync  (admin) — pull new rows from Google Sheets, update passports, anchor new versions */
export async function syncFromSheet(): Promise<SyncResult> {
  await wait(900);
  const s = await getStore();
  const result: SyncResult = { processed: 0, synced: 0, duplicates: 0, errors: 0, passportsUpdated: [], log: [] };
  const now = new Date().toISOString();
  const pending = s.records.filter((r) => r.syncStatus !== "SYNCED" && r.syncStatus !== "DUPLICATE");
  const byPassport = new Map<string, SkillRecord[]>();

  for (const r of pending) {
    result.processed++;
    const p = s.passports[r.passportId];
    const required = [r.studentId, r.passportId, r.recordId, r.skillId, r.skillName, r.skillCategory, r.badgeCode, r.dateEarned];
    if (required.some((v) => !v) || !p || p.studentId !== r.studentId) {
      r.syncStatus = "ERROR";
      r.syncNotes = !p ? "Unknown Passport ID" : p.studentId !== r.studentId ? "Student ID does not match passport" : "Missing required field";
      result.errors++;
      result.log.push({ recordId: r.recordId, status: "ERROR", note: r.syncNotes });
      continue;
    }
    const current = p.versions.at(-1)?.skills ?? [];
    const queued = byPassport.get(p.passportId) ?? [];
    const dup = [...current, ...queued.map(toSkill)].some((x) => x.recordId === r.recordId || x.skillId === r.skillId);
    if (dup) {
      r.syncStatus = "DUPLICATE";
      r.syncNotes = "Skill already on passport — skipped";
      result.duplicates++;
      result.log.push({ recordId: r.recordId, status: "DUPLICATE", note: r.syncNotes });
      continue;
    }
    queued.push(r);
    byPassport.set(p.passportId, queued);
  }

  for (const [pid, recs] of byPassport) {
    const p = s.passports[pid]!;
    const prev = p.versions.at(-1);
    const nextNum = (prev?.version ?? 0) + 1;
    const v = await makeVersion(p, nextNum, [...(prev?.skills ?? []), ...recs.map(toSkill)], now);
    p.versions.push(v);
    for (const r of recs) {
      r.syncStatus = "SYNCED";
      r.syncedVersion = `V${nextNum}`;
      r.syncedAt = now.slice(0, 16).replace("T", " ") + " UTC";
      r.syncNotes = null;
      result.synced++;
      result.log.push({ recordId: r.recordId, status: "SYNCED", note: `${pid} → V${nextNum}` });
    }
    result.passportsUpdated.push({ passportId: pid, newVersion: nextNum });
  }
  persist();
  return result;
}

/** GET /verify/:code  (public, no login) */
export async function verifyByCode(code: string): Promise<VerifyResult> {
  await wait(500);
  const s = await getStore();
  const c = code.trim().toUpperCase();
  for (const p of Object.values(s.passports)) {
    const v = p.versions.find((x) => x.verificationCode === c);
    if (v) {
      const recomputed = await sha256(canonicalPassport(p, v.version, v.skills));
      const { versions, ...info } = p;
      const latest = versions.at(-1)!.version;
      return {
        found: true,
        documentAuthentic: recomputed === v.documentHash,
        issuerAuthentic: true,
        isLatest: v.version === latest,
        latestVersion: latest,
        issuer: BTU_ISSUER,
        passport: info,
        version: v,
        recomputedHash: recomputed,
      };
    }
  }
  return { found: false, documentAuthentic: false, issuerAuthentic: false, isLatest: false };
}

/** POST /verify/document  (public) — body: the passport content as printed on a PDF */
export async function verifyDocumentContent(
  passport: Pick<Passport, "passportId" | "firstName" | "lastName" | "firstIssued">,
  version: number,
  skills: PassportSkill[],
): Promise<{ recomputedHash: string; matches: boolean; anchoredHash: string | null }> {
  await wait(400);
  const s = await getStore();
  const anchored = s.passports[passport.passportId]?.versions.find((v) => v.version === version)?.documentHash ?? null;
  const recomputedHash = await sha256(canonicalPassport(passport, version, skills));
  return { recomputedHash, matches: recomputedHash === anchored, anchoredHash: anchored };
}

// ---------- mock student auth (backend: BTU SSO / OAuth) ----------
const AUTH_KEY = "btu-passport-session";
export async function loginStudent(email: string): Promise<{ email: string } | null> {
  await wait();
  const p = await getMyPassport(email);
  if (!p) return null;
  window.localStorage.setItem(AUTH_KEY, p.email);
  return { email: p.email };
}
export function currentStudentEmail(): string | null {
  return typeof window === "undefined" ? null : window.localStorage.getItem(AUTH_KEY);
}
export function logoutStudent() {
  window.localStorage.removeItem(AUTH_KEY);
}
